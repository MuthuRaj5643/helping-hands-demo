import json
import boto3
from boto3.dynamodb.conditions import Attr


db = boto3.resource('dynamodb')
volunteer_table = db.Table('VolunteerData-copy')
request_table = db.Table('Needy_request-copy')

def lambda_handler(event, context):
    
    try:
        if(event['resource'] == '/getpastrequests-copy'):
            return fetch_request(event , 'resolved')

        elif(event['resource'] == '/getpendingrequests-copy'):
            return fetch_request(event , 'pending')
            
        elif(event['resource'] == '/get-volunteer-by-city-copy'):
        
            result = fetch_volunteer(event,'volunteer_city','city_name')
            if not result:
                result = fetch_volunteer(event,'volunteer_state','state_name')
                
            return build_response(200,result)
            
        
    except Exception as e:
        
             print(e)
             return build_response(400,"ERROR")
            

def fetch_request(event,request_status):
    
        response = request_table.scan(
        
                FilterExpression = Attr('needy_email').eq(event['queryStringParameters']['needy_email']) & Attr('status_id').eq(request_status)
            )
        
        result = response['Items']
        while 'LastEvaluatedKey' in response:
            response = request_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            result.extend(response['Items'])
            
        return build_response(200,result)

        

# param1 -> volunteer_city or volunteer_state , param2 -> city_name,state_name

def fetch_volunteer(event, param1 , param2):   

            print(param1,param2)
            response = volunteer_table.scan(
        
                FilterExpression = Attr(param1).eq(event['queryStringParameters'][param2])
        
            )
            

            result = response['Items']
            while 'LastEvaluatedKey' in response:
                response = volunteer_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                result.extend(response['Items'])
            
            return result
            
        
        
def build_response(status_code , data):
    
            return {
                'statusCode': status_code,
                'headers': {
                    Content-Type': 'application/json',
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type, Authorization, Access-Control-Allow-Credentials, Access-Control-Allow-Origin, Access-Control-Allow-Methods",
                    "Access-Control-Allow-Methods": "PUT,GET,POST,DELETE,OPTIONS",
                    "Access-Control-Allow-Credentials" : "true"                },
                'body' : json.dumps(data)
            }

