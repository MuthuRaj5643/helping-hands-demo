import json
import boto3

ses = boto3.client('ses')

def lambda_handler(event, context):
    # TODO implement
    for record in event['Records']:
        if record['eventName'] == 'INSERT':
            response = verify_email(record['dynamodb']['NewImage']['volunteer_email']['S'])
                
        elif record['eventName'] == 'REMOVE':
            response = delete_email(record['dynamodb']['OldImage']['volunteer_email']['S'])
                
        return {
            'statusCode': 200,
            'body': json.dumps(response)
        }
            
 

def verify_email(email):
    try:
        ses.verify_email_identity(
            EmailAddress = email
        )
        return "verified"
        
    except Exception as e:
        
        print(e)
        return "verification failed"
        
def delete_email(email):
    try:
        ses.delete_identity(
            Identity = email    
        )
        return "removed"
        
    except Exception as e:
        print(e)
        return "failed to remove"
