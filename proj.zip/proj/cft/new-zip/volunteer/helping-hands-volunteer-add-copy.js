const AWS = require('aws-sdk');
AWS.config.update( {
  region: 'us-east-1'
});
const dynamodb = new AWS.DynamoDB.DocumentClient();
const dynamodbTableName = 'VolunteerData-copy';
const addpath= '/helping-hands-volunteer-add-copy';
const editpath = '/updatestatus';



exports.handler = async function(event) {
  console.log('Request event: ', event);
  let response;
  switch(true) {
    case event.httpMethod === 'POST' && event.path === addpath:
      response = await saveProduct(JSON.parse(event.body));
      break;
    case event.httpMethod === 'PATCH' && event.path === editpath:
      const requestBody = JSON.parse(event.body);
      response = await modifyProduct(requestBody.request_id, requestBody.updateKey, requestBody.updateValue);
      break;
    
    default:
      response = buildResponse(404, '404 Not Found');
  }
  return response;
}

async function saveProduct(requestBody) {
  const params = {
    TableName: dynamodbTableName,
    Item: requestBody,
    ConditionExpression: 'attribute_not_exists(volunteer_email)'
  }
  return await dynamodb.put(params).promise().then(() => {
    const body = {
      Operation: 'SAVE',
      Message: 'SUCCESS',
      Item: requestBody
    }
    return buildResponse(200, body);
  }, (error) => {
    console.error(' error handling : ', error);
    return buildResponse(error['statusCode'],error['code'])
  })
}

async function modifyProduct(request_id, updateKey, updateValue) {
  const params = {
    TableName: dynamodbTableName,
    Key: {
      'request_id': request_id
    },
    UpdateExpression: `set ${updateKey} = :value`,
    ExpressionAttributeValues: {
      ':value': updateValue
    },
    ReturnValues: 'UPDATED_NEW'
  }
  return await dynamodb.update(params).promise().then((response) => {
    const body = {
      Operation: 'UPDATE',
      Message: 'SUCCESS',
      UpdatedAttributes: response
    }
    return buildResponse(200, body);
  }, (error) => {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  })
}

function buildResponse(statusCode, body) {
  return {
    statusCode: statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': '*',
      'Access-Control-Allow-Methods': '*'
    },
    body: JSON.stringify(body)
  }
}

