VOLUNTEER PANEL:


volunteer api:[ post request]

paths                                lambda function

helping-hands-volunteer-add-copy     helping-hands-volunteer-add-copy

dynamodb: VolunteerData-copy

triggerlambda: volunteer-send-email-copy


NEEDY PANEL:

needy api:

path                                  lambda function

get-volunteer-by-city-copy       -    helping-hands-needy-panel-copy [ GET ]
getpastrequests-copy             -    helping-hands-needy-panel-copy [ GET ]
getpendingrequests-copy          -    helping-hands-needy-panel-copy [ GET ]
postrequest-copy                 -    needypanel-copy [ POST , OPTIONS]
updatestatus-copy                -    needypanel-copy [ PATCH , OPTIONS]

dynamodb : Needy_Request-copy

trigger lambda : needy-send-email-copy







NeedyPostPathName:
    Type: String
    Default: postrequest-copy
  NeedyUpdatePathName:
    Type: String
    Default: updatestatus-copy
  GetVolunteerPathName:
    Type: String
    Default: get-volunteer-by-city-copy
  GetPastReqPathName:
    Type: String
    Default: getpastrequests-copy 
  GetPendingReqPathName:
    Type: String
    Default: getpendingrequests-copy