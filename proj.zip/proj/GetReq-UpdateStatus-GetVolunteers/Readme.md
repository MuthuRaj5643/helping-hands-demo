This code contains the module for the following functionalities,

1. Get past requests and pending request 

 * uses GET method
 * get requests with email id [ parameter -> needy_email]
 
2. List all volunteers 

 [ parameters -> city_name,state_name]

 * uses GET method
 * first it checks for volunteer in current city [ city_name]
 * if no volunteer is available then it checks by state [ state_name ]
 
