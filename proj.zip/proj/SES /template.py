def create_mail_template():
    
    html_data = "<h2> Hello User , </h2><br> <p><i> &emsp;&emsp; Thank you for availing our service. &ensp;  We look forward  to serve you  better</i></p><br><br> <b><i> Have a nice day !</i></b>"
    try:
        #creating a mail template for needy request
        response = ses.create_template(
           Template={
             'TemplateName': 'needyresponsetemplate',
             'SubjectPart': 'Welcome to helping hands',
             'TextPart': 'Thank You for choosing us',
             'HtmlPart': html_data,
            }
        )
        
    except Exception as e:
        print(e)
        return "template creation failed"
        
    return "template created"	
