import json
import boto3
from boto3.dynamodb.conditions import Attr

table_name = 'demo_db_for_req'
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(table_name)

def lambda_handler(event , context):
    try:
        response = table.scan(
            FilterExpression = Attr('needy_email').eq(event['queryStringParameters']['needy_email'])    
        )
        return {
            'statusCode' : 200,
            'headers':{
                'Content-type' : 'application/json',
                "Access-control-Allow-Headers" : "*",
                "Access-control-Allow-Origin" : "*",
                "Access-control-Allow-Methods" : "OPTIONS,POST,GET",
                "Access-control-Allow-Credentials" : "true"
            },
            'body' : json.dumps(response['Items'])

        }
    except Exception as e:
        return {
            'headers':{
                'Content-type' : 'application/json',
                "Access-control-Allow-Headers" : "*",
                "Access-control-Allow-Origin" : "*",
                "Access-control-Allow-Methods" : "OPTIONS,POST,GET",
                "Access-control-Allow-Credentials" : "true"
            },
            'body' : json.dumps("Error")
        }

