import json
import boto3

source_mail = 'muthuraj5643@gmail.com'
ses = boto3.client('ses')
db = boto3.resource('dynamodb')

#mail1 = "muthuraj5643@gmail.com"
#mail2 = "muthuceg7@gmail.com"

#mail_list = [mail1 , mail2]


def lambda_handler(event, context):
    
    # TODO implement
    email_body ="" 
    try:
        # iterate over records
        for record in event['Records']:
            if record['eventName'] == 'INSERT':
                email_body = send_needy_approval(record)
                #send_email(record)
                
        volunteer_list = []   
        #needy_city = record['dynamodb']['NewImage']['city_name']['S']
        #volunteer_list = fetch_volunteer_list(needy_city)
        volunteer_list = fetch_volunteer_list()
        
        #print("Volunteer list")
        #for volunteer in volunteer_list:
        #    print(volunteer)
            
        send_request_volunteer(email_body , volunteer_list)
        
        #print(create_mail_template())
        
        #testing bulk  emails
        #for address in volunteer_list:
        #    print(send_mail_to_needy(address))
        
    except Exception as e:
        print(e)
        return "Oh no"
        
    print("Success")
    
    
def send_needy_approval(record):
    
    try:
    
        #1.fetch the data of the INSERT event on Request table
    
        needy_info=""
    
        # newImage dynamodb dictionary has NewImage dictionary which cotains the incoming values
        newImage = record['dynamodb']['NewImage']
    
        #extracting needy_name from newImage
        sender_name ="<b>Name : </b>" + "<i>" + newImage['needy_name']['S'] + "</i>"
        # request_id is the email id of the needy
        sender_email = "<b>Email :  </b>" + "<i>" + newImage['request_id']['S'] + "</i>"  
        exam_name = "<b>Exam Name : </b>" + "<i>" + newImage['exam_name']['S'] + "</i>"
        city_name = "<b>City Name : </b>" + "<i>" + newImage['city_name']['S'] + "</i>"
    
        needy_info = needy_info + "<br><br>" + sender_name + "<br><br>" + sender_email + " <br><br>" + exam_name + "<br><br>" + city_name
    
        #print(needy_info)
        #print("hi")
    
        #2.Take the email address from the insert event and send a confirmation mail to needy
        
        to_address = newImage['request_id']['S']
        send_mail_to_needy(to_address)
        print("Needy mail initiated")
        
        #3. return the info related to needy 
        return needy_info
   
    except Exception as e:
        
        print(e)
        print("Needy mail initiation failed")

        
    
def send_mail_to_needy(to_address):
    
    try:
        ses.send_templated_email(
            
             Source = source_mail ,
             Destination = {
                
                'ToAddresses' : [ to_address ]
                #'CcAddresses' : ['muthuraj5643@gmail.com']
            },
            ReplyToAddresses = [ source_mail ],
            Template = 'needyresponsetemplate',
            TemplateData = '{"replace tag " : " with value "}'        
                
        )
        print("Needy mail sent")
        
    except Exception as e:
        
        print(e)
        print("needy mail failed")
    

def fetch_volunteer_list():
    
    # fetch the list of volunteers
    try:
        table = db.Table('Volunteer')
        response = table.scan()
        #response = table.scan(
        #    
        #    FilterExpression = Attr('volunteer_city').eq(needy_city)
        #    
        #    )
        print("volunteer fetch completed")
        return  [ i['volunteer_email'] for i in response['Items']]
    
    except Exception as e:
        print(e)
        print("fetching volunteer failed")




def send_request_volunteer(email_body , volunteer_list):
    
    try:
        for volunteer_mailid in volunteer_list:
            send_mail_to_volunteer(email_body , volunteer_mailid)
            
        print("Mail sent to all volunteer")
        
    except Exception as e:
        print(e)
        print("Mail to volunteer failed")
    

def send_mail_to_volunteer(email_body , to_address):
    
    subject_data = "Request from a Needy"
    #body_data = "Details of the Needy \n" + email_body
    html_data = "<h3> Hello Volunteers , </h3><br><p> &emsp; &emsp; A needy is in need of you. The details of the needy are attached below </p><br>" + email_body
    try:
        ses.send_email(
            
            Source = source_mail,
            Destination = {
                'ToAddresses' : [ to_address ]
                #'CcAddresses' : [ source_mail ]
            },
            Message = {
                'Subject':{
                    
                    'Charset' : 'UTF-8' ,
                    'Data' : subject_data ,
                    
                },
                'Body':{
                    
                    'Html' :{
                         
                         'Charset' : 'UTF-8',
                         'Data'    : html_data ,
                    },
                    
                },

            },
            ReplyToAddresses = [ source_mail ] ,
            
            )
        print("mail sent to " + to_address)
        
    except Exception as e:
        print(e)
        print("mail to " + to_address + "failed")
