import json
import boto3

ses = boto3.client('ses')


def lambda_handler(event, context):
    # TODO implement
    
    resp = create_mail_template()
    return {
        'statusCode': 200,
        'body': json.dumps(resp)
    }




def create_mail_template():
    
    html_data = "<h2> Hello User , </h2><br> <p><i> &emsp;&emsp; Thank you for availing our service. &nbsp;We look forward  to serve you  better</i></p><br><br> <b><i> Have a nice day !</i></b>"
    try:
        #creating a mail template for needy request
        response = ses.create_template(
           Template={
             'TemplateName': 'needy_response_template',
             'SubjectPart': 'Welcome to helping hands',
             'TextPart': 'Thank You for choosing us',
             'HtmlPart': html_data,
            }
        )
        
    except Exception as e:
        print(e)
        return "template creation failed"
        
    return "template created"	
